﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpfvlc_test
{
    /// <summary>
    /// Interaction logic for EmojiSelector.xaml
    /// </summary>
    public partial class EmojiSelector : UserControl
    {
        public EmojiSelector()
        {
            InitializeComponent();
            Loaded += OnLoad;
        }
        public EventHandler OnImageSelect;
        Border Def_bd;
        private void OnLoad(object sender, RoutedEventArgs e)
        {
            foreach (var item in SysFaces.Faces)
            {
                Def_bd = new Border();
                Def_bd.MouseDown += new System.Windows.Input.MouseButtonEventHandler(Def_bd_MouseDown);
                Def_bd.BorderThickness = new Thickness(0);
                Def_bd.ToolTip = item.Name;
                //Def_bd.Style = (Style)this.FindResource("Normal_Border_Style");
                Image image = new Image();
                image.Stretch = Stretch.UniformToFill;
                image.SetValue(RenderOptions.BitmapScalingModeProperty, BitmapScalingMode.HighQuality);
                image.Margin = new Thickness(5);
                image.Width = 26;
                image.Height = 26;
                image.Source = new BitmapImage(new Uri("/wpfvlc-test;component/sysface/" + item.Md5String + ".gif", UriKind.Relative));
                image.Tag = item;
                Def_bd.Child = image;
                this.emojiListGrid.Children.Add(Def_bd);
            }
            Loaded -= OnLoad;
        }
       
      

        void Def_bd_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            Image Img = (sender as Border).Child as Image;
            OnImageSelect?.Invoke(Img, null);
            Popup popup = ((this.Parent as Border).Parent as Grid).Parent as Popup;
            if (popup != null)
            {
                popup.IsOpen = false;
            }

        }
       
    }
}
