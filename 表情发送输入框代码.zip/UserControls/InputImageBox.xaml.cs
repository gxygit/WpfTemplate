﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpfvlc_test
{
    public partial class InputImageBox : UserControl, INotifyPropertyChanged
    {
        public InputImageBox()
        {
            InitializeComponent();
            selector.OnImageSelect -= Onselect;
            selector.OnImageSelect += Onselect;
        }



        private bool m_pending_change;

        public string Msg { get; set; } = "";
       

        public event PropertyChangedEventHandler PropertyChanged;

        private void send_Click(object sender, RoutedEventArgs e)
        {
            ImageExpender Img_Exp = new ImageExpender();
            Img_Exp.Stretch = Stretch.None;
            Img_Exp.Visibility = Visibility.Visible;
            string facePath = "6d177c2e8caa44b47950afd1c2d94ea1.gif";
            Stream imageStream = System.Windows.Application.GetResourceStream(new Uri("/wpfvlc-test;component/sysface/" + facePath, UriKind.Relative)).Stream;
            System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(imageStream);
            Img_Exp.Image = bitmap;
            Img_Exp.Width = 25;
            Img_Exp.Height = 25;
            Img_Exp.Location = "/wpfvlc-test;component/sysface/" + facePath;
            Img_Exp.ToolTip = "/wpfvlc-test;component/sysface/" + facePath;
            Img_Exp.Tag = "大哭";
            InlineUIContainer IUC = new InlineUIContainer();
            IUC.Child = Img_Exp;
            SetContent(IUC);
        }
        void SetContent(InlineUIContainer iUC)
        {
            richText.BeginChange();
            var obj = richText.CaretPosition.Parent;
            if (obj is FlowDocument)
            {
                Paragraph paragraph = new Paragraph(iUC);
                this.richText.Document.Blocks.Add(paragraph);
            }
            else if (obj is Run)
            {
                Run run = (Run)obj;
                var paragraph = richText.CaretPosition.Paragraph;
                var endTextPointer = richText.Selection.End;
                var beforeText = new TextRange(run.ContentStart, endTextPointer);//前面的文本
                var afterText = new TextRange(run.ContentEnd, endTextPointer);//后面的文本
                Run runBefore = new Run(beforeText.Text);
                Run runAfter = new Run(afterText.Text);

                if (!string.IsNullOrEmpty(afterText.Text))
                    paragraph.Inlines.InsertAfter(run, runAfter);
                paragraph.Inlines.InsertAfter(run, iUC);
                if (!string.IsNullOrEmpty(beforeText.Text))
                    paragraph.Inlines.InsertAfter(run, runBefore);
                paragraph.Inlines.Remove(run);//删除原有text

            }
            else if (obj is Paragraph paragraph)
            {
                var var1 = richText.CaretPosition.GetAdjacentElement(LogicalDirection.Backward);
                var var2 = richText.CaretPosition.GetAdjacentElement(LogicalDirection.Forward);
                if (var1.GetType() == typeof(InlineUIContainer))
                {
                    paragraph.Inlines.InsertAfter((InlineUIContainer)var1, iUC);
                }
                else if (var2.GetType() == typeof(InlineUIContainer))
                {
                    paragraph.Inlines.InsertBefore((InlineUIContainer)var2, iUC);
                }
                else
                {
                    paragraph.Inlines.Add(iUC);
                }
            }
            richText.EndChange();
        }
        public ImageExpender GegImageExpender(GifFace face)
        {
            ImageExpender Img_Exp = new ImageExpender();
            Img_Exp.Stretch = Stretch.UniformToFill;
            Img_Exp.Visibility = Visibility.Visible;
            string facePath = $"{face.Md5String}.gif";
            Stream imageStream = Application.GetResourceStream(new Uri("/wpfvlc-test;component/sysface/" + facePath, UriKind.Relative)).Stream;
            System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(imageStream);
            Img_Exp.Image = bitmap;
            Img_Exp.Location = "/wpfvlc-test;component/sysface/" + facePath;
            Img_Exp.Tag = face.Name;
            Img_Exp.Width=25;
            Img_Exp.Height= 25;
            Img_Exp.Margin = new Thickness(2);
            return Img_Exp;
        }
        private void Onselect(object sender, EventArgs e)
        {
            var image = sender as Image;
            var face = image.Tag as GifFace;
            InlineUIContainer IUC = new InlineUIContainer();
            var img =GegImageExpender(face);
            IUC.Child = img;
            IUC.BaselineAlignment = BaselineAlignment.Center;
            SetContent(IUC);
            var next = richText.CaretPosition.GetNextInsertionPosition(LogicalDirection.Forward);
            if (next != null)
                richText.CaretPosition = next;
            richText.Document.Focus();
            richText.Document.Blocks.LastBlock.Focus();
        }

        private string GetText()
        {
            string result = "";
            TextPointer cur = richText.Document.ContentStart;
            while (cur.CompareTo(richText.Document.ContentEnd) < 0)
            {
                TextPointer next = cur.GetNextInsertionPosition(LogicalDirection.Forward);
                if (next == null)
                    break;
                var ele = cur.GetAdjacentElement(LogicalDirection.Forward);
                if(ele is Paragraph paragraph)
                {
                    foreach (var item in paragraph.Inlines)
                    {
                        if(item is Run run)
                        {
                            var runText = new TextRange(run.ContentStart, run.ContentEnd);
                            var text = runText.Text;
                            result += text;
                        }else if(item is InlineUIContainer iuc)
                        {
                            if(iuc.Child is ImageExpender image)
                            {
                                result += $"[{image.Tag}]";
                            }
                        }
                    }
                    cur = paragraph.ContentEnd;
                }
                else
                {

                }


            }
            

            return result;
        }

        private void get_Click(object sender, RoutedEventArgs e)
        {
           var txt =  GetText();
           Msg = txt;
        }

        private void clear_click(object sender, RoutedEventArgs e)
        {
            richText.Document.Blocks.Clear();
            Msg = "";
        }

        private void Open(object sender, RoutedEventArgs e)
        {
            pop.IsOpen = true;
        }
    }
}
