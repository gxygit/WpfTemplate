﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace wpfvlc_test
{
    public partial class FRichTextBox : System.Windows.Controls.RichTextBox
    {
        public FRichTextBox()
        {
            SetValue(Block.LineHeightProperty, 1.0);
            DataObject.AddCopyingHandler(this, new DataObjectCopyingEventHandler(OnCopy));
        }
      
        protected void OnCopy(object o, DataObjectCopyingEventArgs e)
        {
            string clipboard = "";

            for (TextPointer p = Selection.Start, next = null;
                 p != null && p.CompareTo(Selection.End) < 0;
                 p = next)
            {
                next = p.GetNextInsertionPosition(LogicalDirection.Forward);
                if (next == null)
                    break;

                var emoji = (next.Parent as Run)?.PreviousInline as InlineUIContainer;

                if (emoji == null && next.Parent != p.Parent)
                    emoji = (p.Parent as Run)?.NextInline as InlineUIContainer;

                if (emoji != null && (p.Parent as Run).PreviousInline != emoji)
                    clipboard += (emoji?.Child as ImageExpender)?.Tag?.ToString();
                else
                    clipboard += new TextRange(p, next).Text;
            }

            Clipboard.SetText(clipboard);
            e.Handled = true;
            e.CancelCommand();
        }
        BitmapImage bitmap = new BitmapImage(new Uri("/sysface/6d177c2e8caa44b47950afd1c2d94ea1.gif",UriKind.Relative));
        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            //if (e.Key == Key.Back)
            //{
            //    e.Handled = true;
            //    BeginChange();
            //    var obj = CaretPosition.Parent;
            //    var endTextPointer = Selection.End;
            //    if(obj is Paragraph paragraph)
            //    {
            //        var beforeText = new TextRange(paragraph.ContentStart, endTextPointer);//前面的文本
            //        TextPointer last = endTextPointer.GetNextInsertionPosition(LogicalDirection.Backward);
            //        TextRange word = new TextRange(last, endTextPointer);
            //        Replace(word, new Run());
            //    }
            //    else if(obj is Run run)
            //    {
            //        var beforeText = new TextRange(run.ContentStart, endTextPointer);//前面的文本
            //        TextPointer last = endTextPointer.GetNextInsertionPosition(LogicalDirection.Backward);
            //        TextRange word = new TextRange(last, endTextPointer);
            //        Replace(word, new Run());
            //    }


            //    EndChange();
            //}
            base.OnPreviewKeyDown(e);
        }
        protected override void OnTextChanged(TextChangedEventArgs e)
        {
            if (m_pending_change)
                return;

            m_pending_change = true;

            base.OnTextChanged(e);

            /* This will prevent our operation from polluting the undo buffer, but it
             * will create an infinite undo stack... need to fix this. */
            BeginChange();

            m_pending_change = true;

            TextPointer cur = Document.ContentStart;
            while (cur.CompareTo(Document.ContentEnd) < 0)
            {
                TextPointer next = cur.GetNextInsertionPosition(LogicalDirection.Forward);
                if (next == null)
                    break;

                TextRange word = new TextRange(cur, next);
                if (word.Text == "[")
                {
                    //ImageExpender Img_Exp = new ImageExpender();
                    //Img_Exp.Stretch = Stretch.None;
                    //Img_Exp.Visibility = Visibility.Visible;
                    //string facePath = "6d177c2e8caa44b47950afd1c2d94ea1.gif";
                    //Stream imageStream = System.Windows.Application.GetResourceStream(new Uri("/wpfvlc-test;component/sysface/" + facePath, UriKind.Relative)).Stream;
                    //System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(imageStream);
                    //Img_Exp.Image = bitmap;

                    //Img_Exp.Location = "/wpfvlc-test;component/sysface/" + facePath;
                    //Img_Exp.ToolTip = "/wpfvlc-test;component/sysface/" + facePath;
                    //Img_Exp.Tag = facePath;

                    InlineUIContainer IUC = new InlineUIContainer();

                    //GifImage gif = new GifImage(@"E:\test-zxing\test\wpfvlc-test\UserControls\bizhi.gif");

                    //GifImage gif = new GifImage();
                    // gif.Source = "/wpfvlc-test;component/sysface/6d177c2e8caa44b47950afd1c2d94ea1.gif";
                    //gif.Stretch = Stretch.None;
                    //grid.Children.Add(gif);
                    Image image = new Image();
                    image.Source = new BitmapImage(new Uri("/sysface/6d177c2e8caa44b47950afd1c2d94ea1.gif", UriKind.Relative));
                
                    image.Width = 19;
                   
                    IUC.Child = image;

    


                    bool caret_was_next = (0 == next.CompareTo(CaretPosition));
                    next = Replace(word, IUC);


                    if (caret_was_next)
                        CaretPosition = next;
                }

                cur = next;
            }

            EndChange();

            m_pending_change = false;

            // FIXME: debug
            //Console.WriteLine(XamlWriter.Save(Document));
        }

        private bool m_pending_change = false;

        public TextPointer Replace(TextRange range, Inline inline)
        {
            var run = range.Start.Parent as Run;
            if (run == null)
                return range.End;

            var before = new TextRange(run.ContentStart, range.Start).Text;
            var after = new TextRange(range.End, run.ContentEnd).Text;
            var inlines = run.SiblingInlines;

            /* Insert new inlines in reverse order after the run */
            if (!string.IsNullOrEmpty(after))
                inlines.InsertAfter(run, new Run(after));

            inlines.InsertAfter(run, inline);

            if (!string.IsNullOrEmpty(before))
                inlines.InsertAfter(run, new Run(before));

            TextPointer ret = inline.ContentEnd; // FIXME
            inlines.Remove(run);
            return ret;
        }
    }
    
}
