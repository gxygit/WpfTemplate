﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpfvlc_test
{
    /// <summary>
    /// Interaction logic for FTextBlock.xaml
    /// </summary>
    public partial class FTextBlock : TextBlock
    {
        static FTextBlock()
        {
            TextProperty.OverrideMetadata(typeof(FTextBlock), new FrameworkPropertyMetadata(
                    (string)TextBlock.TextProperty.GetMetadata(typeof(TextBlock)).DefaultValue,
                    (o, e) => (o as FTextBlock).OnTextChanged(e.NewValue as string)));
        }
        private void OnTextChanged(string text)
        {
            Inlines.Clear();
            if (string.IsNullOrEmpty(text))
                return;
            string[] msgs = Regex.Split(text, @"(\[[^\][]+\])");
            foreach (var msg in msgs)
            {
                if (!string.IsNullOrEmpty(msg))
                {
                    if (msg.StartsWith("[")&& msg.EndsWith("]"))
                    {
                        string name = msg.Substring(1, msg.Length - 2);
                        GifFace face = SysFaces.Faces.Where(f => f.Name == name).FirstOrDefault();
                        if (face != null)
                        {
                            InlineUIContainer iuc = new InlineUIContainer();
                            var image = GegImageExpender(face);
                            iuc.Child = image;
                            Inlines.Add(iuc);
                            continue;
                        }
                    }
                    Inlines.Add(new Run(msg) { BaselineAlignment=BaselineAlignment.Center});
                }
            }
        }
        public ImageExpender GegImageExpender(GifFace face)
        {
            ImageExpender Img_Exp = new ImageExpender();
            Img_Exp.Stretch = Stretch.UniformToFill;
            Img_Exp.Visibility = Visibility.Visible;
            string facePath = $"{face.Md5String}.gif";
            Stream imageStream = Application.GetResourceStream(new Uri("/wpfvlc-test;component/sysface/" + facePath, UriKind.Relative)).Stream;
            System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(imageStream);
            Img_Exp.Image = bitmap;
            Img_Exp.Location = "/wpfvlc-test;component/sysface/" + facePath;
            Img_Exp.Tag = face.Name;
            Img_Exp.Width = 25;
            Img_Exp.Height = 25;
            Img_Exp.Margin = new Thickness(2);
            return Img_Exp;
        }
        public FTextBlock()
        {
            InitializeComponent();
        }
        public new string Text
        {
            get => m_text_dpd.GetValue(this) as string;
            set => m_text_dpd.SetValue(this, value);
        }
        public static new readonly DependencyProperty TextProperty =
           DependencyProperty.Register(nameof(Text), typeof(string), typeof(FTextBlock));

        private static readonly DependencyPropertyDescriptor m_text_dpd =
           DependencyPropertyDescriptor.FromProperty(TextProperty, typeof(FTextBlock));

    }
}
