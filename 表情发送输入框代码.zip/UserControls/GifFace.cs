﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace wpfvlc_test
{
    public class GifFace
    {
        public string Name { get; set; }
        public string Md5String { get; set; }
        public int FrameCount { get; set; }

    }
}
