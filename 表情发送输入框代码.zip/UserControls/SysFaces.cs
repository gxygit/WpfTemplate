﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace wpfvlc_test
{
    public class SysFaces
    {
        public static GifFace 微笑 = new GifFace() { Name = "微笑",Md5String = "1e376a99d4059562772aad9ac065fd71",FrameCount = 0 };
        public static GifFace 大笑 = new GifFace() { Name = "大笑",Md5String = "c5ce7689438e5ee92c5942d4885fc198",FrameCount = 0 };
        public static GifFace 偷笑 = new GifFace() { Name = "偷笑",Md5String = "d2ff68289e44c32d61f17e9cfb8f781a",FrameCount = 2 };
        public static GifFace 憨笑 = new GifFace() { Name = "憨笑",Md5String = "564396330c9e704c27533dd0a9f38d56",FrameCount = 0 };
        public static GifFace 得意 = new GifFace() { Name = "得意",Md5String = "33991a718d98b7bde46d1656acd1d84f",FrameCount = 0 };
        public static GifFace 可爱 = new GifFace() { Name = "可爱",Md5String = "1eac4820cb2162ad0ea9050f730701ea",FrameCount = 0 };
        public static GifFace 害羞 = new GifFace() { Name = "害羞",Md5String = "afb7b910b894d8638a5f5f60d66080bb",FrameCount = 4 };
        public static GifFace 乖 = new GifFace() { Name = "乖",Md5String = "6eeeea78151b0d992342b5d974ea9748",FrameCount = 0 };
        public static GifFace 淘气 = new GifFace() { Name = "淘气",Md5String = "3567d74d273570047d563a52487b458d",FrameCount = 0 };
        public static GifFace 调皮 = new GifFace() { Name = "调皮",Md5String = "17a002956048d2cc3e7136a60995f4c5",FrameCount = 2 };
        public static GifFace 流泪 = new GifFace() { Name = "流泪",Md5String = "6d177c2e8caa44b47950afd1c2d94ea1",FrameCount = 2 };
        public static GifFace 大哭 = new GifFace() { Name = "大哭",Md5String = "f2468ad19982b6109525f86e60da0a40",FrameCount = 2 };
        public static GifFace 撇嘴 = new GifFace() { Name = "撇嘴",Md5String = "f4075f32764665658fe69d475536685f",FrameCount = 0 };
        public static GifFace 闭嘴 = new GifFace() { Name = "闭嘴",Md5String = "97aac5ef30ca5c313f5055d3303a901a",FrameCount = 2 };
        public static GifFace 嘘 = new GifFace() { Name = "嘘",Md5String = "ea12132c217e29cc32a70ef2123baa55",FrameCount = 3 };
        public static GifFace 鄙视 = new GifFace() { Name = "鄙视",Md5String = "0fd150d82ae7f2d174c9601f9ee09247",FrameCount = 0 };
        public static GifFace 傲慢 = new GifFace() { Name = "傲慢",Md5String = "8484e2fcd13826ff6d311fa23f6133f1",FrameCount = 0 };
        public static GifFace 白眼 = new GifFace() { Name = "白眼",Md5String = "46e7c6b53203f314943f5af66f6b9daf",FrameCount = 0 };
        public static GifFace 思考 = new GifFace() { Name = "思考",Md5String = "8c1066c3a4fc9115b46e3ae72a19e3f4",FrameCount = 2 };
        public static GifFace 困 = new GifFace() { Name = "困",Md5String = "fd2bdb138346f328795d068df107ec90",FrameCount = 1 };
        public static GifFace 睡 = new GifFace() { Name = "睡",Md5String = "d6c03a77dc812595b2f41fdde34d05a6",FrameCount = 2 };
        public static GifFace 汗 = new GifFace() { Name = "汗",Md5String = "fd2f51cd66989306299d8ad075abbc89",FrameCount = 1 };
        public static GifFace 尴尬 = new GifFace() { Name = "尴尬",Md5String = "b143058415f04e4f21302736326fb37c",FrameCount = 2 };
        public static GifFace 惊讶 = new GifFace() { Name = "惊讶",Md5String = "c6fbb9628da63dc12c9a1fef25dea934",FrameCount = 0 };
        public static GifFace 惊恐 = new GifFace() { Name = "惊恐",Md5String = "4a19620c98f2d809ea46900a0b552d7c",FrameCount = 0 };
        public static GifFace 疑问 = new GifFace() { Name = "疑问",Md5String = "7e9cbda5e0b325f01d478f8e4adf69b2",FrameCount = 0 };
        public static GifFace 晕 = new GifFace() { Name = "晕",Md5String = "18c3ccd14d992d8e5aa30acfe670d42f",FrameCount = 0 };
        public static GifFace 敲打 = new GifFace() { Name = "敲打",Md5String = "d237de97c3277b7749ce839db39b0649",FrameCount = 2 };
        public static GifFace 难过 = new GifFace() { Name = "难过",Md5String = "f2e7df81f1e48584a82c82f99d266b7c",FrameCount = 0 };
        public static GifFace 委屈 = new GifFace() { Name = "委屈",Md5String = "3ced67ed7484ec180470b6cf8f0e44b3",FrameCount = 0 };
        public static GifFace 色 = new GifFace() { Name = "色",Md5String = "5c0aacf4ce01a07aa72ced20edfb1fb0",FrameCount = 0 };
        public static GifFace 抓狂 = new GifFace() { Name = "抓狂",Md5String = "fd78f2b8f16086a940e90f370b2bb0d4",FrameCount = 1 };
        public static GifFace 愤怒 = new GifFace() { Name = "愤怒",Md5String = "c6d1d4982260a4bad13aab943f7799f0",FrameCount = 0 };
        public static GifFace 吐 = new GifFace() { Name = "吐",Md5String = "658d87d64e128385f28a59c15aa8cb91",FrameCount = 2 };
        public static GifFace 衰 = new GifFace() { Name = "衰",Md5String = "ae2b37bc2c8186a5dad63a583ad278cb",FrameCount = 0 };
        public static GifFace 再见 = new GifFace() { Name = "再见",Md5String = "b6db7f3a9e8a9c864046eb0eaa15942d",FrameCount = 0 };
        public static GifFace 左拥抱 = new GifFace() { Name = "左拥抱",Md5String = "3890735fdd2f25319367532f660bbcd2",FrameCount = 0 };
        public static GifFace 右拥抱 = new GifFace() { Name = "右拥抱",Md5String = "28a6dcccc96ad6d3082a0ff5554bebd6",FrameCount = 0 };
        public static GifFace 闪人 = new GifFace() { Name = "闪人",Md5String = "eb06e9170d5b470f124d3943f537e714",FrameCount = 0 };
        public static GifFace 刀 = new GifFace() { Name = "刀",Md5String = "d32893593db6217773e102bd694db4d8",FrameCount = 2 };
        public static GifFace 吻 = new GifFace() { Name = "吻",Md5String = "11d117a72c9cd5ffa2110c31cb4a385b",FrameCount = 0 };
        public static GifFace 爱情 = new GifFace() { Name = "爱情",Md5String = "7f73aeabe8ddb4bb23e06de4e6072e40",FrameCount = 0 };
        public static GifFace 心碎 = new GifFace() { Name = "心碎",Md5String = "b5fbcef53bf2d695db6bd48faa326585",FrameCount = 1 };
        public static GifFace 鲜花 = new GifFace() { Name = "鲜花",Md5String = "5bc342dfc4b92d4c0cad3a4207a99380",FrameCount = 0 };
        public static GifFace 枯萎 = new GifFace() { Name = "枯萎",Md5String = "9ef7d4c187f298a10953f5096cbe9162",FrameCount = 0 };
        public static GifFace 胜利 = new GifFace() { Name = "胜利",Md5String = "f08d998e04027d92feaf0f8667bb016c",FrameCount = 0 };
        public static GifFace OK = new GifFace() { Name = "OK",Md5String = "f143718613f47bb929e7134b2457f260",FrameCount = 0 };
        public static GifFace 大拇指 = new GifFace() { Name = "大拇指",Md5String = "2f5113cfd0a33bfec485c222051db205",FrameCount = 0 };
        public static GifFace 弱 = new GifFace() { Name = "弱",Md5String = "2ea09b4e887a6871e22d6e52a014179c",FrameCount = 0 };
        public static GifFace 握手 = new GifFace() { Name = "握手",Md5String = "a21bf8c01f41b9148b81aa1b53fb3a0e",FrameCount = 0 };
        public static GifFace 蛋糕 = new GifFace() { Name = "蛋糕",Md5String = "47198bf11c75a03e6249a1ccc1064bce",FrameCount = 0 };
        public static GifFace 咖啡 = new GifFace() { Name = "咖啡",Md5String = "d6bde4b624846fd08500053358e154ae",FrameCount = 0 };
        public static GifFace 吃饭 = new GifFace() { Name = "吃饭",Md5String = "e3aac3a4e1e36a02959f62d9bbcab7ac",FrameCount = 0 };
        public static GifFace 太阳 = new GifFace() { Name = "太阳",Md5String = "75132ac5d361fd71a0b8acc6d99b7692",FrameCount = 0 };
        public static GifFace 月亮 = new GifFace() { Name = "月亮",Md5String = "5bbb83756e3e652b43f9f03d638718b4",FrameCount = 0 };
        public static GifFace 星星 = new GifFace() { Name = "星星",Md5String = "dcb31cac1b742034e9cdc5254f309d00",FrameCount = 0 };
        public static GifFace 便便 = new GifFace() { Name = "便便",Md5String = "490183579bb95ab6eee1d695cdaef213",FrameCount = 0 };
        public static GifFace 猪头 = new GifFace() { Name = "猪头",Md5String = "ede07ac7f02fbc613381069a77ff1b5c",FrameCount = 0 };
        public static GifFace 钱 = new GifFace() { Name = "钱",Md5String = "eeb68b5c092155df924e69b2a1de21f9",FrameCount = 0 };
        public static GifFace 嗨 = new GifFace() { Name = "Hi",Md5String = "33037bedc05c33f5998f875c608d4ba1",FrameCount = 2 };

        public static List<GifFace> Faces { get; set; } = new List<GifFace>()
        {
            微笑, 大笑, 偷笑, 憨笑, 得意, 可爱, 害羞, 乖, 淘气, 调皮, 流泪, 大哭, 撇嘴, 闭嘴, 嘘, 鄙视, 傲慢, 白眼, 思考, 困, 睡,汗, 尴尬, 惊讶, 惊恐, 疑问, 晕, 敲打, 难过, 委屈, 色, 抓狂, 愤怒, 吐, 衰, 再见, 左拥抱, 右拥抱, 闪人, 刀, 吻, 爱情, 心碎, 鲜花, 枯萎, 胜利, OK, 大拇指, 弱, 握手,蛋糕, 咖啡, 吃饭,太阳, 月亮, 星星, 便便, 猪头, 钱, 嗨
        };

    }
}
