﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Vlc.DotNet.Core.Interops;
using Vlc.DotNet.Core.Interops.Signatures;
using Vlc.DotNet.Wpf;
using Vlc.DotNet.Core;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Threading;
using System.Threading.Tasks;

namespace wpfvlc_test
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class VlcLivePlayerWindow : Window, INotifyPropertyChanged
    {
        public string Txt { get; set; }
        public VlcLivePlayerWindow()
        {
            InitializeComponent();


            //vlc1. = new Vlc.DotNet.Wpf.VlcVideoSourceProvider();// = new Vlc.DotNet.Core.VlcMediaPlayer(dir);

            Loaded += MainWindow_Loaded;
        }

        public ObservableCollection<string> Reps { get; set; } = new ObservableCollection<string>();

        public event PropertyChangedEventHandler PropertyChanged;
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            var currentAssembly = Assembly.GetEntryAssembly();
            var currentDirectory = new FileInfo(currentAssembly.Location).DirectoryName;
            var dir = new DirectoryInfo(System.IO.Path.Combine(currentDirectory, "libvlc", "win-x86"));
            var options = new string[]
           {
                ":network-caching=1000"
           };
            vlc1.SourceProvider.CreatePlayer(dir, options);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            vlc1.SourceProvider.MediaPlayer.Play("rtsp://wowzaec2demo.streamlock.net/vod/mp4:BigBuckBunny_115k.mov");
        }

        private void vlc1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("7777777");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Task.Factory.StartNew(() =>
            {
                while (true)
                {
                    this.Dispatcher.Invoke(new Action(() =>
                    {
                        Reps.Add(Guid.NewGuid().ToString());
                        //listbox.SelectedIndex = listbox.Items.Count - 1;
                        //listbox.ScrollIntoView(listbox.SelectedItem);
                    }));
                    Thread.Sleep(1000);

                }
            });

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            TextBlockBarrage textBlockBarrage = new TextBlockBarrage()
            {
                Text = "666[大哭]66[大哭]666",
                FromSeconds = 10,
                Translation_Left = 0,
                Translation_Right = -650,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right,
                TextWrapping = TextWrapping.Wrap,
                MaxWidth = 200,
                FontSize = 20,
                Foreground = new SolidColorBrush(Colors.White),
                Background = new SolidColorBrush(Colors.Transparent),
                Opacity = 0.8,
                Enabled = true,
                Padding = new Thickness(5, 5, 5, 5)
            };


            dm.Children.Add(textBlockBarrage);

            //GifImage gif = new GifImage();
            //gif.Source = "/wpfvlc-test;component/sysface/6d177c2e8caa44b47950afd1c2d94ea1.gif";
            //gif.Stretch = Stretch.None;
            //sta.Children.Add(gif);
        }
    }
}
