﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace wpfvlc_test
{
    /// <summary>
    /// 纯文字弹幕控件
    /// </summary>
    public class TextBlockBarrage : FTextBlock
    {
        TranslateTransform TranslateTransformClass;
        /// <summary>
        /// 获取或设置控件动画执行时长 秒
        /// </summary>
        public double FromSeconds { get; set; }
        /// <summary>
        /// 加载时间
        /// </summary>
        public DateTime LoadingTime { get; set; }
        /// <summary>
        /// 运行完毕离左边的距离
        /// </summary>
        public double Translation_Left { get; set; }
        /// <summary>
        /// 运行完毕离右边边的距离
        /// </summary>
        public double Translation_Right { get; set; }

        public bool Enabled { get; set; }
        /// <summary>
        /// 初始化
        /// </summary>
        public TextBlockBarrage()
            : base()
        {

            LoadingTime = DateTime.Now;
            TranslateTransformClass = new TranslateTransform();
            this.RenderTransform = TranslateTransformClass;
            this.Loaded += new RoutedEventHandler(TextBlockBarrage_Loaded);
        }



        /// <summary>
        /// 加载触发时间
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void TextBlockBarrage_Loaded(object sender, RoutedEventArgs e)
        {
            if (TranslateTransformClass == null)
                return;
            if (!Enabled)
            {
                return;
            }
            else
            {
                Enabled = false;
            }
            //执行时间
            Duration duration = new Duration(TimeSpan.FromSeconds(FromSeconds));
            DoubleAnimation da = new DoubleAnimation(Translation_Left, Translation_Right, duration);
            da.AutoReverse = false;
            da.FillBehavior = FillBehavior.HoldEnd;

            TranslateTransformClass.BeginAnimation(TranslateTransform.XProperty, da);
            this.Loaded -= new RoutedEventHandler(TextBlockBarrage_Loaded);
        }


    }
}
